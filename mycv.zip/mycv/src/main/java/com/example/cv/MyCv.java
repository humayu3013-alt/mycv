package com.example.cv;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MyCv {
    private String name;
    private int age;
    private String address;
    private String email;
}
