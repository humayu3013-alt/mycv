package com.example.cv;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.assertj.core.api.Assertions.*;

public class MyCvTest {

    private static MyCv myCv;

    @BeforeClass
    public static void setupCv() {
        myCv = new MyCv("John", 30, "Yellow Street", "john_yellow@dummy_mail.com");
    }

    @Test
    public void printCv() {
        System.out.println("\n=== My CV ===");
        System.out.printf("Name    : %s%n", myCv.getName());
        System.out.printf("Age     : %d%n", myCv.getAge());
        System.out.printf("Address : %s%n", myCv.getAddress());
        System.out.printf("Email   : %s%n", myCv.getEmail());
        System.out.println("\nBeautified Object: " + myCv);
    }

    @AfterClass
    public static void validateCvFields() {
        assertThat(myCv.getName()).isNotBlank();
        assertThat(myCv.getAge()).isGreaterThan(0);
        assertThat(myCv.getAddress()).isNotBlank();
        assertThat(myCv.getEmail()).contains("@");
    }
}
